import React from 'react';

// importing navigation
import DefaultNavigation from './navigation/index';

function App() {
  return (
    <DefaultNavigation />
  );
};

export default App;
