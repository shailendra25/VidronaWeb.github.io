import React from 'react';

import Button from './Button';

// base
const Base = ({children}: any) => {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      {children}
    </div>
  );
};

export const Default = () => <Base><Button /></Base>;

export const CustomTitle = () => <Base><Button text="Custom Text" /></Base>;

export const Disabled = () =>
  <Base><Button text="Disabled" isDisabled={true} /></Base>;

export const PressAlert = () =>
  <Base><Button text="Press for Alert" onPress={() => alert('Hi!!!')} /></Base>;

export default {
  title: 'Component/Button',
  component: Button,
};
