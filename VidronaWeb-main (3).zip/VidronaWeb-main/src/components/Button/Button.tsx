import React from 'react';
import {motion} from 'framer-motion';

// component data
const typeProperty = {
  dark: {
    backgroundColor: '#011627',
    backgroundColorHover: '#373F41',
    borderColor: '#FFFFFF',
    color: '#FFFFFF',
  },
  light: {
    backgroundColor: '#FFFFFF',
    backgroundColorHover: '#F4F5F4',
    borderColor: '#FFFFFF',
    color: '#011627',
  },
};

export type ButtonParams = {
  text: string;
  type: 'dark' | 'light';
  isDisabled?: boolean;
  onPress: () => void;
  style?: any;
}

const Button = (props: ButtonParams) => {
  const _onPress = () => {
    if (props.isDisabled) {
      return;
    }
    props.onPress();
  };

  return (
    <motion.div
      style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 4,
        padding: 10,
        paddingLeft: 20,
        paddingRight: 20,
        margin: 5,
        fontWeight: 'bold',
        fontSize: 18,
        borderWidth: 2,
        borderStyle: 'solid',
        borderColor: typeProperty[props.type].borderColor,
        backgroundColor: typeProperty[props.type].backgroundColor,
        color: typeProperty[props.type].color,
        opacity: props.isDisabled ? 0.3 : 1,
        ...props.style,
      }}
      whileHover={{
        scale: 1.04,
        cursor: 'pointer',
        backgroundColor: typeProperty[props.type].backgroundColorHover,
      }}
      whileTap={{
        scale: 1.04,
        cursor: 'pointer',
        backgroundColor: typeProperty[props.type].backgroundColorHover,
      }}
      onClick={_onPress}
    >
      {props.text}
    </motion.div>
  );
};

Button.defaultProps = {
  text: 'Button Text',
  type: 'light',
  isDisabled: false,
  onPress: () => {},
  style: {},
};

export default Button;
