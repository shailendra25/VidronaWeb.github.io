import React from 'react';
import {motion} from 'framer-motion';

// importing styles
import './IndustryCard.css';

export type IndustryCardParams = {
  title: string;
  body: string;
  link: string;
  image: string;
}

const IndustryCard = (props: IndustryCardParams) => {
  return (
    <motion.div
      className="IndustryCardWrapper"
      style={{
        backgroundColor: '#FFFFFF',
        color: '#363636',
      }}
      whileHover={{
        backgroundColor: '#363636',
        color: '#FFFFFF',
      }}
    >
      <motion.div className="IndustryCardImage">
        <motion.img
          src={props.image}
          alt={props.title}
        />
      </motion.div>
      <motion.h3
        className="IndustryCardHeading"
      >
        {props.title}
      </motion.h3>
      <motion.p
        className="IndustryCardPara"
      >
        {props.body}
      </motion.p>
      <motion.a
        className="IndustryCardBtn"
        whileHover={{
          cursor: 'pointer',
        }}
        onClick={() => {
          window.location.href = props.link;
        }}
      >
        VIEW MORE
      </motion.a>
    </motion.div>
  );
};

IndustryCard.defaultProps = {
  title: 'Title of Card',
  // eslint-disable-next-line max-len
  body: 'We have services for systematic predictive inspection for the New power lines, semi finished lines',
  link: '',
  image: require('../../../assets/icons/telecom.svg').default,
};

export default IndustryCard;
