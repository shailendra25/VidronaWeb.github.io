import React from 'react';
import {motion} from 'framer-motion';

// importing styles
import './FullPageCarousel.css';

const FullPageCarousel = () => {
  return (
    <motion.div className="fullPageCarouselWrapper">
      {/* background image */}
      <motion.img
        className="fullPageCarouselBackImage"
        src={require('./assets/home.png').default}
      />
      {/* Information */}
      <motion.div className="fullPageCarouselInfo">
        <motion.h1>
          We are
        </motion.h1>
        <motion.h1>
          A Precision Predictive
        </motion.h1>
        <motion.h1>
          Physical Asset Management
        </motion.h1>
        <motion.h1>
          Company
        </motion.h1>
        <br />
        <motion.h4
          style={{
            marginTop: 40,
          }}
        >
          We provide comprehensive AI based solutions for your Energy
          Asset Maintenance and Management requirements
        </motion.h4>
        <motion.a
          whileHover={{
            cursor: 'pointer',
          }}
        >
          Learn More
        </motion.a>
        <br />
        <motion.div
          style={{
            marginTop: 40,
          }}
        >
          <motion.a
            className="fullPageCarouselInfoButton"
            whileHover={{
              cursor: 'pointer',
            }}
          >
            Get Brochure
          </motion.a>
          <motion.a
            className="fullPageCarouselInfoButton"
            style={{
              backgroundColor: 'white',
              marginLeft: 20,
            }}
            whileHover={{
              cursor: 'pointer',
            }}
          >
            Get Quote
          </motion.a>
        </motion.div>
      </motion.div>
      {/* controls */}
      <motion.div
        className="fullPageControllerLeft"
        whileHover={{
          cursor: 'pointer',
        }}
      >
        <motion.img
          src={require('../../../assets/icons/arrowLeft.svg').default}
          alt="show left content"
          onClick={() => alert('left')}
        />
      </motion.div>
      <motion.div
        className="fullPageControllerRight"
        whileHover={{
          cursor: 'pointer',
        }}
      >
        <motion.img
          src={require('../../../assets/icons/arrowRight.svg').default}
          alt="show left content"
          onClick={() => alert('right')}
        />
      </motion.div>
    </motion.div>
  );
};

export default FullPageCarousel;
