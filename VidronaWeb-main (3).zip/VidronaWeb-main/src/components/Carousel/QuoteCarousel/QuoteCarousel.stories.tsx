import React from 'react';

import ListCarousel from './QuoteCarousel';

export const Default = () => <ListCarousel />;

export default {
  title: 'Component/ListCarousel',
  component: ListCarousel,
};
