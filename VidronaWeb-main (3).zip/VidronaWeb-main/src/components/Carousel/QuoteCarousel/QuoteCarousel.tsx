import React, {useState} from 'react';
import {motion} from 'framer-motion';

// importing styles
import './QuoteCarousel.css';

// importing default raw data for component
import raw from './raw.js';

// params for component
export type QuoteCarouselParams = {
  title: string;
  data: any [];
}

const QuoteCarousel = (props: QuoteCarouselParams) => {
  const {title, data} = props;

  // component states
  const [index, setIndex] = useState(0);

  // update selected page
  const selectPage = (value: number) => {
    if (index + value < data.length && index + value >= 0) {
      setIndex(index + value);
    }
    return;
  };

  return (
    <motion.div className="QuoteCarouselWrapper BaseContentWrapper">
      <motion.h5 className="QuoteCarouselHeading">
        {title}
      </motion.h5>
      {/* Controllers and image */}
      <motion.div className="QuoteCarouselControllers">
        <motion.div
          className="QuoteCarouselControllerBtn"
          whileHover={{
            cursor: 'pointer',
            scale: 1.2,
          }}
          whileTap={{
            cursor: 'pointer',
            scale: 1.2,
          }}
          onClick={() => selectPage(-1)}
        >
          <motion.img
            src={require('../../../assets/icons/arrowLeft.svg').default}
          />
        </motion.div>
        <motion.img
          alt={data[index].heading}
          src={data[index].image}
          style={{
            width: 140,
            height: 140,
            borderRadius: '50%',
          }}
        />
        <motion.div
          className="QuoteCarouselControllerBtn"
          whileHover={{
            cursor: 'pointer',
            scale: 1.2,
          }}
          whileTap={{
            cursor: 'pointer',
            scale: 1.2,
          }}
          onClick={() => selectPage(1)}
        >
          <motion.img
            src={require('../../../assets/icons/arrowRight.svg').default}
          />
        </motion.div>
      </motion.div>
      <motion.h4 className="QuoteCarouselBody">
        {data[index].body}
      </motion.h4>
    </motion.div>
  );
};

QuoteCarousel.defaultProps = {
  title: 'Quote Carousel',
  data: raw,
};

export default QuoteCarousel;
