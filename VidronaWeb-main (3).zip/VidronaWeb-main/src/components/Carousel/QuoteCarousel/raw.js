export default [
  {
    // eslint-disable-next-line max-len
    body: 'Best asset management company ever. They have most top notch technologies, highly reliable service provider and executes with remarkable results. Most recommended.',
    image: require('../../../assets/images/services/1.png').default,
  },
  {
    // eslint-disable-next-line max-len
    body: 'Best asset management company ever. They have most top notch technologies, highly reliable service provider and executes with remarkable results. Most recommended.',
    image: require('../../../assets/images/services/2.png').default,
  },
  {
    // eslint-disable-next-line max-len
    body: 'A few lines about the industry and the problems faced by clients along with what solutions the company has in store for the clients.',
    image: require('../../../assets/images/services/3.png').default,
  },
  {
    // eslint-disable-next-line max-len
    body: 'A few lines about the industry and the problems faced by clients along with what solutions the company has in store for the clients.',
    image: require('../../../assets/images/services/1.png').default,
  },
];
