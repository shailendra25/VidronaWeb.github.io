import React, {useState} from 'react';
import {motion} from 'framer-motion';

// importing styles
import './SectionCarousel.css';

export type SectionCarouselParams = {
  data: any[];
}

const SectionCarousel = ({data}: SectionCarouselParams) => {
  const [index, setIndex] = useState(0);
  return (
    <motion.div className="sectionCarouselWrapper">
      <motion.div key={index} className="sectionCarouselHoverList">
        {
          data.map((d, i) => {
            return (
              <motion.div
                key={d.name}
                className="sectionCarouselHoverItem"
                style={{
                  backgroundColor: index === i ? '#FFAF50' : '#F4F4F4',
                }}
                whileHover={{
                  backgroundColor: '#FFAF50',
                  cursor: 'pointer',
                }}
                onTapStart={() => setIndex(i)}
              >
                <motion.h6>
                  {d.name}
                </motion.h6>
              </motion.div>
            );
          })
        }
      </motion.div>
      <motion.div
        className="sectionCarouselImageWrapper"
        style={{
          backgroundImage: `url(${data[index].image})`,
        }}
      >
        <motion.div
          className="sectionCarouselImageBtn"
          whileHover={{
            cursor: 'pointer',
          }}
          onClick={() => window.location.href = data[index].link}
        >
          <motion.h6>
            Apply Now
          </motion.h6>
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

SectionCarousel.defaultProps = {
  data: [
    {
      name: 'Drone/UAV Pilots',
      image: require('./t.png').default,
      link: '/careers/drones',
    },
    {
      name: 'Software Engineering',
      image: require('./t.png').default,
      link: '/careers/drones',
    },
  ],
};

export default SectionCarousel;
