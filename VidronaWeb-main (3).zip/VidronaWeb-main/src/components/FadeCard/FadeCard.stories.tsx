import React from 'react';

import FadeCard from '../FadeCard/FadeCard';

export const Default = () => <FadeCard />;

export const Custom = () =>
  <FadeCard
    title="Sample Card"
    body="This is the sample custom body of the fade card component"
    link="http://vidrona.com/"
  />;

export default {
  title: 'Component/FadeCard',
  component: FadeCard,
};
