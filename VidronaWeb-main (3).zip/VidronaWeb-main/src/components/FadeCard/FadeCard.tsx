import React from 'react';
import {motion, useSpring} from 'framer-motion';

export type FadeCardParams = {
  title: string;
  body: string;
  image: string;
  link: string;
}

// some constants
const height = 200;
const width = 300;
const borderRadius = 4;
const txInitial = 160;

const FadeCard = (props: FadeCardParams) => {
  const titlePosition = useSpring(txInitial);
  const overlayOpacity = useSpring(0);
  const descOpacity = useSpring(0);
  return (
    <motion.div
      style={{
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundImage:
        `url(${props.image})`,
        minHeight: height,
        width: width,
        borderRadius: borderRadius,
        borderBottomColor: '#FFAF50',
        borderBottomWidth: 2,
        overflow: 'hidden',
      }}
      whileHover={{
        scale: 1.04,
      }}
      whileTap={{
        scale: 1.04,
      }}
      onTapStart={() => {
        titlePosition.set(10);
        overlayOpacity.set(0.4);
        descOpacity.set(1);
      }}
      onHoverStart={() => {
        titlePosition.set(10);
        overlayOpacity.set(0.4);
        descOpacity.set(1);
      }}
      onHoverEnd={() => {
        titlePosition.set(txInitial);
        overlayOpacity.set(0);
        descOpacity.set(0);
      }}
    >
      <motion.div
        style={{
          position: 'absolute',
          height: height,
          width: width,
          borderRadius: borderRadius,
          backgroundColor: 'black',
          opacity: overlayOpacity,
        }}
      />
      <motion.div
        style={{
          position: 'absolute',
          height: '200px',
          width: '260px',
        }}
      >
        <motion.h4
          style={{
            color: '#FFFFFF',
            position: 'absolute',
            top: titlePosition,
            left: 10,
            margin: 0,
            alignSelf: 'center',
            fontSize: 20,
          }}
          whileHover={{
          }}
        >
          {props.title}
        </motion.h4>
        <motion.p
          style={{
            position: 'absolute',
            color: '#FFFFFF',
            textAlign: 'justify',
            fontSize: 14,
            fontWeight: 800,
            top: 40,
            left: 10,
            right: 10,
            opacity: descOpacity,
          }}
        >
          {props.body}
        </motion.p>
        <motion.a
          style={{
            position: 'absolute',
            bottom: 10,
            left: 10,
            color: '#FFFFFF',
            cursor: 'pointer',
            opacity: descOpacity,
          }}
          href={props.link}
        >
          Know More
        </motion.a>
      </motion.div>
    </motion.div>
  );
};

FadeCard.defaultProps = {
  title: 'Data Acquisition',
  // eslint-disable-next-line max-len
  body: 'Quality data collection services offered by Drones, Helicopter and Satellites catering as per the customer and project requirement',
  image: require('../../assets/images/drone.png').default,
  link: '',
};

export default FadeCard;
