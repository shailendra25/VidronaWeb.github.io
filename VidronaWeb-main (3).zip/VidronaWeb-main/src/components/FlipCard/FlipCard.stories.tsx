import React from 'react';

import FlipCard from './FlipCard';

const Base = ({children}: any) => {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      {children}
    </div>
  );
};

export const Default = () => <Base><FlipCard /></Base>;

export default {
  title: 'Component/FlipCard',
  component: FlipCard,
};
