import React, {useState} from 'react';
import {motion} from 'framer-motion';

export type FlipCardParams = {
  title: string;
  body: string;
  image: any;
}

const FlipCard = (props: FlipCardParams) => {
  const [isFlipped, setIsFlipped] = useState(false);

  const onUpdate = (latest: any) => {
    if (latest.rotateY > 90 && isFlipped === false) {
      setIsFlipped(true);
    } else if (latest.rotateY < 90 && isFlipped === true) {
      setIsFlipped(false);
    }
  };

  return (
    <motion.div
      whileHover={{rotateY: 180}}
      transition={{duration: 0.25}}
      onUpdate={onUpdate}
    >
      {
        !isFlipped ? (
          <div
            style={{
              position: 'relative',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
              height: 200,
              width: 200,
              backgroundColor: '#FFFFFF',
              borderRadius: 8,
              borderColor: 'black',
              borderWidth: 2,
              boxShadow: '10px 10px 100px 4px #ebe6e6',
            }}
          >
            <img
              style={{
                width: 160,
                height: 'auto',
                alignSelf: 'center',
              }}
              src={props.image}
            />
            <h4
              style={{
                color: '#AE160D',
                position: 'absolute',
                bottom: 0,
                alignSelf: 'center',
                fontSize: 18,
              }}
            >
              {props.title}
            </h4>
          </div>
        ) : (
          <div
            style={{
              position: 'relative',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
              height: 200,
              width: 200,
              backgroundColor: '#FFFFFF',
              borderRadius: 8,
              borderColor: 'black',
              borderWidth: 2,
              boxShadow: '4px 4px 10px 4px #ebe6e6',
            }}
          >
            <div
              style={{
                height: 200,
                width: 200,
                transform: 'rotateY(180deg)',
              }}
            >
              <h5
                style={{
                  color: '#011627',
                  textAlign: 'justify',
                  margin: 10,
                  fontSize: 14,
                  fontWeight: 800,
                }}
              >
                {props.body}
              </h5>
              <motion.a
                style={{
                  position: 'absolute',
                  left: 10,
                  bottom: 10,
                  fontSize: 14,
                  fontWeight: 800,
                }}
                whileHover={{
                  cursor: 'pointer',
                }}
              >
                Know More
              </motion.a>
            </div>
          </div>
        )
      }
    </motion.div>
  );
};

FlipCard.defaultProps = {
  title: 'vSense',
  // eslint-disable-next-line max-len
  body: '“A few lines about the industry and the problems faced by clients along with what solutions the company has in store for the clients”',
  image: require('../../assets/customers/1.png').default,
};

export default FlipCard;
