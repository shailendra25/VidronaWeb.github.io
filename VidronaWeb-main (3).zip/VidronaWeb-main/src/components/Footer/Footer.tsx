import React from 'react';
import {motion} from 'framer-motion';

// importing styles
import './Footer.css';

// importing navs
import navs from '../../navigation/navigator';

// raw data
const socialLinks = [
  {
    key: 'Facebook',
    link: 'https://www.facebook.com/vidrona/',
    image: require('../../assets/icons/social/footer/facebook.png').default,
  },
  {
    key: 'Twitter',
    link: 'https://twitter.com/vidrona',
    image: require('../../assets/icons/social/footer/twitter.png').default,
  },
  {
    key: 'Linkedin',
    link: 'https://www.linkedin.com/company/vidrona-ltd/',
    image: require('../../assets/icons/social/footer/linkedin.png').default,
  },
];
// const productLinks = [
//   {
//     name: 'vSense',
//     link: '/products/vsense',
//   },
//   {
//     name: 'vNautilus',
//     link: '/products/vnautilus',
//   },
//   {
//     name: 'vSolis',
//     link: '/products/vsolis',
//   },
//   {
//     name: 'vAelous',
//     link: '/products/vaelous',
//   },
//   {
//     name: 'vTurris',
//     link: '/products/vturris',
//   },
//   {
//     name: 'vRail',
//     link: '/products/vrail',
//   },
// ];
// const featureLinks = [
//   {
//     name: 'Media & Entertainment',
//     link: '/m&e',
//   },
//   {
//     name: 'Products',
//     link: '/products',
//   },
//   {
//     name: 'Analysis',
//     link: '/analysis',
//   },
//   {
//     name: 'Professional Services',
//     link: '/professional-services',
//   },
// ];

const Footer = () => {
  return (
    <motion.div className="footerWrapper BaseContentWrapper">
      <motion.div className="footerInfoContainer">
        <motion.div className="footerInfoContactUs">
          <motion.div className="footerInfoVidrona">
            <motion.img
              src={require('../../assets/vidrona.png').default}
              alt="Vidrona"
              className=""
            />
            <motion.h4>
              VIDRONA
            </motion.h4>
          </motion.div>
          <motion.h6>
            World Leader in Precision Predictive Physical Asset Management
          </motion.h6>
          <motion.div className="footerInfoContacts">
            {
              socialLinks.map((link) => {
                return (
                  <motion.img
                    src={link.image}
                    alt={link.key}
                    key={link.key}
                    onClick={() => window.open(link.link, '_blank')}
                    whileHover={{
                      cursor: 'pointer',
                      scale: 1.2,
                    }}
                  />
                );
              })
            }
          </motion.div>
        </motion.div>
        <motion.div className="footerInfoLinks">
          <motion.div className="footerInfoLinksContainer">
            <motion.h5>
              Quick Links
            </motion.h5>
            {
              navs.reverse().map((n) => {
                return (
                  <motion.a key={n.name} href={n.path} >
                    {n.name}
                  </motion.a>
                );
              })
            }
          </motion.div>
          {/* <motion.div className="footerInfoLinksContainer">
            <motion.h5>
              Products
            </motion.h5>
            {
              productLinks.map((links) => {
                return (
                  <motion.a key={links.name} href={links.link} >
                    {links.name}
                  </motion.a>
                );
              })
            }
          </motion.div> */}
          {/* <motion.div className="footerInfoLinksContainer">
            <motion.h5>
              Features
            </motion.h5>
            {
              featureLinks.map((links) => {
                return (
                  <motion.a key={links.name} href={links.link} >
                    {links.name}
                  </motion.a>
                );
              })
            }
          </motion.div> */}
        </motion.div>
      </motion.div>
      <motion.div className="footerCopyRightContainer">
        <motion.h6>
          2015-2021 Vidrona Ltd, UK
        </motion.h6>
        <motion.h6>
          Incubated by ESA BIC UK
          Supported by STFC, UK
        </motion.h6>
      </motion.div>
    </motion.div>
  );
};

export default Footer;
