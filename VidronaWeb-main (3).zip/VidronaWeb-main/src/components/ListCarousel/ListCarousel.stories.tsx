import React from 'react';

import ListCarousel from './ListCarousel';

export const Default = () => <ListCarousel />;

export default {
  title: 'Component/ListCarousel',
  component: ListCarousel,
};
