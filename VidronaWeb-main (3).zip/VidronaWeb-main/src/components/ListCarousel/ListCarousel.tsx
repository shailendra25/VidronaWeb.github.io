import React, {useState} from 'react';
import {motion} from 'framer-motion';

// importing styles
import './ListCarousel.css';

// importing default raw data for component
import raw from './raw.js';

// params for component
export type ListCarouselParams = {
  title: string;
  data: any [];
  flipped: boolean;
}

const ListCarousel = (props: ListCarouselParams) => {
  const {title, data, flipped} = props;

  // component states
  const [index, setIndex] = useState(0);

  // update selected page
  const selectPage = (value: number) => {
    if (index + value < data.length && index + value >= 0) {
      setIndex(index + value);
    }
    return;
  };

  return (
    <motion.div className="ListCarouselWrapper BaseContentWrapper">
      <motion.h5>
        {title}
      </motion.h5>
      <motion.div
        className={
          flipped ?
            'ListCarouselInnerContainerReverse' : 'ListCarouselInnerContainer'}
      >
        <motion.div className="ListCarouselInnerSection">
          <motion.img
            src={data[index].image}
          />
        </motion.div>
        <motion.div className="ListCarouselInnerSection">
          <motion.div className="ListCarouselInnerInfo">
            <motion.h4>
              {data[index].heading}
            </motion.h4>
            <motion.p>
              {data[index].body}
            </motion.p>
            <motion.a
              whileHover={{
                textDecoration: 'underline',
                textDecorationColor: '#FFAF50',
              }}
              whileTap={{
                textDecoration: 'underline',
                textDecorationColor: '#FFAF50',
              }}
            >
              Read more
            </motion.a>
          </motion.div>
        </motion.div>
      </motion.div>
      <motion.div className="ListCarouselControls">
        <motion.img
          src={require('../../assets/icons/arrowLeft.png').default}
          style={{
            margin: 10,
          }}
          whileHover={{
            cursor: 'pointer',
            scale: 1.2,
          }}
          whileTap={{
            cursor: 'pointer',
            scale: 1.2,
          }}
          onClick={() => selectPage(-1)}
        />
        {
          data.map((d, i) => {
            return (
              <motion.div
                key={d.title}
                style={{
                  width: 10,
                  height: 10,
                  borderRadius: 5,
                  margin: 10,
                  backgroundColor: index === i ? '#C2C2C2' : '#7A7A7A',
                }}
                whileHover={{
                  scale: 1.2,
                }}
                whileTap={{
                  scale: 1.2,
                }}
                onClick={() => setIndex(i)}
              />
            );
          })
        }
        <motion.img
          src={require('../../assets/icons/arrowRight.png').default}
          style={{
            margin: 10,
          }}
          whileHover={{
            cursor: 'pointer',
            scale: 1.2,
          }}
          whileTap={{
            cursor: 'pointer',
            scale: 1.2,
          }}
          onClick={() => selectPage(1)}
        />
      </motion.div>
    </motion.div>
  );
};

ListCarousel.defaultProps = {
  title: 'Our Industry Solutions',
  data: raw,
  flipped: false,
};

export default ListCarousel;
