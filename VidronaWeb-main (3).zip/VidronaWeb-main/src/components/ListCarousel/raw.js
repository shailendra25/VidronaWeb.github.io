export default [
  {
    heading: 'Transmission and Distribution',
    // eslint-disable-next-line max-len
    body: 'A few lines about the industry and the problems faced by clients along with what solutions the company has in store for the clients.',
    image: require('../../assets/images/services/1.png').default,
  },
  {
    heading: 'vSense - 2',
    // eslint-disable-next-line max-len
    body: 'A few lines about the industry and the problems faced by clients along with what solutions the company has in store for the clients.',
    image: require('../../assets/images/services/2.png').default,
  },
  {
    heading: 'vSense - 3',
    // eslint-disable-next-line max-len
    body: 'A few lines about the industry and the problems faced by clients along with what solutions the company has in store for the clients.',
    image: require('../../assets/images/services/3.png').default,
  },
  {
    heading: 'vSense - 4',
    // eslint-disable-next-line max-len
    body: 'A few lines about the industry and the problems faced by clients along with what solutions the company has in store for the clients.',
    image: require('../../assets/images/services/1.png').default,
  },
];
