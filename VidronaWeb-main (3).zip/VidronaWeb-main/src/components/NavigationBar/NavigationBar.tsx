import React from 'react';
import {motion, useSpring} from 'framer-motion';

// importing styles
import './NavigationBar.css';

// importing navs
import navs from '../../navigation/navigator';

const NavigationBar = () => {
  const mobileNavControl = useSpring(-window.innerWidth*0.7);
  return (
    <motion.div className="navbarContainer BaseContentWrapper">
      <motion.div className="navbarSection" id="navbarSectionUpper">
        <motion.div className="navbarSectionUpperSide">
          <motion.h6>
            +447469231693
          </motion.h6>
          <motion.h6>
            info@vidrona.com
          </motion.h6>
        </motion.div>
        <motion.div
          className="navbarSectionUpperSide navbarSectionUpperSideSocialLinks"
        >
          <motion.h6>
            English(US)
          </motion.h6>
          <motion.div>
            <motion.img
              className="navbarSectionUpperSideSocial"
              src={require('../../assets/icons/social/facebook.svg').default}
              alt="Facebook"
              onClick={() => window.open('https://www.facebook.com/vidrona/', '_blank')}
            />
            <motion.img
              className="navbarSectionUpperSideSocial"
              src={require('../../assets/icons/social/twitter.svg').default}
              alt="Twitter"
              onClick={() => window.open('https://twitter.com/vidrona', '_blank')}
            />
            <motion.img
              className="navbarSectionUpperSideSocial"
              src=
                {require('../../assets/icons/social/linkedin.svg').default}
              alt="Linkedin"
              onClick={() => window.open('https://www.linkedin.com/company/vidrona-ltd/', '_blank')}
            />
          </motion.div>
        </motion.div>
      </motion.div>
      <motion.div className="navbarSection" id="navbarSectionLower">
        <motion.div className="navbarSectionLowerSide">
          <img src={require('../../assets/vidrona.png').default} />
          <motion.h2>
            VIDRONA
          </motion.h2>
        </motion.div>
        <motion.div className="navbarSectionLowerSide">
          <nav
            className="navbarSectionNavLinks"
          >
            {
              [...navs].reverse().map((n) => {
                if (n.name === undefined) {
                  return;
                }
                return (
                  <motion.a href={n.path} key={n.path}>
                    {n.name}
                  </motion.a>
                );
              })
            }
          </nav>
          <motion.div
            className="navbarSectionBurger"
            style={{marginLeft: 10}}
          >
            <motion.img
              src={require('./assets/burger.png').default}
              alt="Menu"
              onClick={() => {
                mobileNavControl.set(0);
              }}
            />
          </motion.div>
        </motion.div>
      </motion.div>
      <motion.div
        className="navbarMobileViewLinks"
        style={{
          left: mobileNavControl,
        }}
        onTap={() => mobileNavControl.set(-window.innerWidth*0.7)}
      >
        {
          [...navs].reverse().map((n) => {
            if (n.name === undefined) {
              return;
            }
            console.log(n.name);
            return (
              <motion.a href={n.path} key={n.path}>
                {n.name}
              </motion.a>
            );
          })
        }
        <motion.div className="navbarMobileViewSocial">
          <motion.img
            src={require('./assets/f.png').default}
            alt="Facebook"
            className="navbarMobileViewSocialLink"
            onClick={() => window.open('https://www.facebook.com/vidrona/', '_blank')}
          />
          <motion.img
            src={require('./assets/t.png').default}
            alt="Twitter"
            className="navbarMobileViewSocialLink"
            onClick={() => window.open('https://twitter.com/vidrona', '_blank')}
          />
          <motion.img
            src={require('./assets/l.png').default}
            alt="Linkedin"
            className="navbarMobileViewSocialLink"
            onClick={() => window.open('https://www.linkedin.com/company/vidrona-ltd/', '_blank')}
          />
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

export default NavigationBar;
