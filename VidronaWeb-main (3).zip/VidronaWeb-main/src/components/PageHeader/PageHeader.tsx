import React from 'react';
import {motion} from 'framer-motion';

// importing styles
import './PageHeader.css';

export type PageHeaderParams = {
  title: string;
  links: any[];
  image: string;
};

const PageHeader = ({title, links, image}: PageHeaderParams) => {
  return (
    <motion.div className="PageHeaderWrapper">
      <motion.img
        src={image}
        alt='Page Image'
        className="PageHeaderImage"
      />
      <motion.div className="PageHeaderImageOverlay">
        <motion.h1>
          {title}
        </motion.h1>
      </motion.div>
      <motion.div className="PageHeaderBread">
        <>
          <motion.a href="/" style={{color: '#FFAF50'}}>
            Home
          </motion.a>
        </>
        {
          links.map((t) => {
            return (
              <>
                <motion.img
                  src={require('../../assets/icons/arrowRight.svg').default}
                  alt="arrow right"
                />
                <motion.a key={t} href={t.url}>
                  {t.name}
                </motion.a>
              </>
            );
          })
        }
      </motion.div>
    </motion.div>
  );
};

PageHeader.defaultProps = {
  title: 'About Us',
  links: [{name: 'About Us', url: '/aboutus'}],
  image: require('../../assets/images/pages/aboutus.png').default,
};

export default PageHeader;
