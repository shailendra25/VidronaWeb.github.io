import React from 'react';
import {motion, useSpring} from 'framer-motion';

export type ProfileCardParams = {
  name: string;
  position: string;
  image: string;
  facebook: string;
  twitter: string;
  linkedin: string;
}

// some constants
const size = 200;
const borderRadius = 4;
const overlay = 0.8;

const ProfileCard = (props: ProfileCardParams) => {
  const overlayOpacity = useSpring(0);
  const descOpacity = useSpring(0);
  return (
    <motion.div
      style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <motion.div
        style={{
          position: 'relative',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          backgroundImage:
          `url(${props.image})`,
          height: size,
          width: size,
          borderRadius: borderRadius,
          borderBottomColor: '#FFAF50',
          borderBottomWidth: 2,
        }}
        whileHover={{
          scale: 1.04,
        }}
        whileTap={{
          scale: 1.04,
        }}
        onTapStart={() => {
          overlayOpacity.set(overlay);
          descOpacity.set(1);
        }}
        onHoverStart={() => {
          overlayOpacity.set(overlay);
          descOpacity.set(1);
        }}
        onHoverEnd={() => {
          overlayOpacity.set(0);
          descOpacity.set(0);
        }}
      >
        <motion.div
          style={{
            position: 'absolute',
            height: size,
            width: size,
            borderRadius: borderRadius,
            backgroundColor: 'rgba(255, 175, 80, 0.75)',
            opacity: overlayOpacity,
          }}
        />
        <motion.div
          style={{
            position: 'absolute',
            height: size,
            width: size,
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
            opacity: overlayOpacity,
          }}
        >
          <motion.img
            style={{
              marginLeft: 8,
              marginRight: 8,
            }}
            whileHover={{
              scale: 1.4,
            }}
            whileTap={{
              scale: 1.4,
            }}
            onTapStart={() => window.open(props.facebook, '_blank')}
            src={require('./icons/1.png').default}
          />
          <motion.img
            style={{
              marginLeft: 8,
              marginRight: 8,
            }}
            whileHover={{
              scale: 1.4,
            }}
            whileTap={{
              scale: 1.4,
            }}
            onTapStart={() => window.open(props.twitter, '_blank')}
            src={require('./icons/2.png').default}
          />
          <motion.img
            style={{
              marginLeft: 8,
              marginRight: 8,
            }}
            whileHover={{
              scale: 1.4,
            }}
            whileTap={{
              scale: 1.4,
            }}
            onTapStart={() => window.open(props.linkedin, '_blank')}
            src={require('./icons/3.png').default}
          />
        </motion.div>
      </motion.div>
      <motion.h5
        style={{
          fontFamily: 'Noto Sans',
          fontStyle: 'normal',
          fontWeight: 'bold',
          fontSize: 16,
          color: '#363636',
          margin: 0,
          marginTop: 10,
        }}
      >
        {props.name}
      </motion.h5>
      <motion.h6
        style={{
          fontFamily: 'Noto Sans',
          fontStyle: 'italic',
          fontWeight: 'normal',
          fontSize: 14,
          color: '#363636',
          margin: 0,
        }}
      >
        {props.position}
      </motion.h6>
    </motion.div>
  );
};

ProfileCard.defaultProps = {
  name: 'Sarthak',
  position: 'SDE Inter: Full Stack',
  image: require('../../assets/images/drone.png').default,
  facebook: '',
  twitter: '',
  linkedin: '',
};

export default ProfileCard;
