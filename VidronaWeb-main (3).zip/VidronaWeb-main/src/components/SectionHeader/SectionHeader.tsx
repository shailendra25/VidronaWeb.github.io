import React from 'react';
import {motion} from 'framer-motion';

// font-sizes
const HeaderSizes = {
  h1: 52,
  h2: 44,
  h3: 32,
  h4: 24,
  h5: 16,
  h6: 12,
};

export type SectionHeaderParams = {
  text: string;
  type: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';
  style?: any;
}

const SectionHeader = ({text, type, style}: SectionHeaderParams) => {
  return (
    <motion.h1
      style={{
        fontSize: HeaderSizes[type],
        fontWeight: 900,
        color: '#011627',
        margin: 0,
        textDecoration: 'underline',
        textDecorationWidth: 4,
        textDecorationColor: '#AE160D',
        ...style,
      }}
    >
      {text}
    </motion.h1>
  );
};

SectionHeader.defaultProps = {
  text: 'Header',
  type: 'h1',
  style: {},
};

export default SectionHeader;
