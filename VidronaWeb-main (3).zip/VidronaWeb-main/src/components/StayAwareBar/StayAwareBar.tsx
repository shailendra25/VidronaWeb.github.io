import {motion} from 'framer-motion';
import React from 'react';

// importing styles
import './StayAwareBar.css';

const StayAwareBar = () => {
  return (
    <motion.div className="stayAwareBarWapper BaseContentWrapper">
      <motion.h2>
        Stay aware of your assets with Vidrona
      </motion.h2>
      <motion.div
        className="stayAwareBarVideoWrapper"
        whileHover={{
          cursor: 'pointer',
        }}
        onClick={() => window.open('http://vidrona.com/wp-content/uploads/2019/10/191023_Promo_Web_PreCut_Small_low.mp4', '_blank')}
      >
        <motion.img
          src={require('./assets/2.png').default}
          alt="Youtube Video"
        />
        <motion.a>
          Watch a video about us
        </motion.a>
      </motion.div>
    </motion.div>
  );
};

export default StayAwareBar;
