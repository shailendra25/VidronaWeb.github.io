const colors = {
  tertiary1: '#AE160D',
  tertiary2: '#E47D1E',
  primary: '#FFFFFF',
  secondary: '#011627',
};

export default colors;
