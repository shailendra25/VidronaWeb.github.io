export default {
  margin: '12vw',
};
