import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
} from 'react-router-dom';

// import global components
import NavigationBar from '../components/NavigationBar/NavigationBar';
import Footer from '../components/Footer/Footer';

// importing navigation data
import navs from './navigator';

const DefaultNavigation = () => {
  return (
    <Router>
      <NavigationBar />
      <Switch>
        {
          navs.map((n) => {
            return (
              <Route key={n.path} path={n.path}>
                <n.component />
              </Route>
            );
          })
        }
      </Switch>
      <Footer />
    </Router>
  );
};

export default DefaultNavigation;
