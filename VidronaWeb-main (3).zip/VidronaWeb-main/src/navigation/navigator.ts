// importing Screen
import TestScreen from '../screens/TestScreen/TestScreen';
import HomeScreen from '../screens/HomeScreen/HomeScreen';
import AboutUsScreen from '../screens/AboutUsScreen/AboutUsScreen';
import IndustryScreen from '../screens/Industry/index';
import
IndustryViewScreen
  from '../screens/Industry/IndustryViewScreen/IndustryViewScreen';
import ServiceScreen from '../screens/ServiceScreen/ServiceScreen';
import CareerScreen from '../screens/Career/index';
import ContactUsScreen from '../screens/ContactUsScreen/ContactUsScreen';

export type NavigatorLink = {
  path: string;
  name: undefined | string;
  component: any;
}

const navs: NavigatorLink[] = [
  {
    path: '/test',
    name: undefined,
    component: TestScreen,
  },
  {
    path: '/contactus',
    name: 'Contact Us',
    component: ContactUsScreen,
  },
  {
    path: '/careers',
    name: 'Careers',
    component: CareerScreen,
  },
  {
    path: '/services',
    name: 'Services',
    component: ServiceScreen,
  },
  {
    path: '/industry/:industryId',
    name: undefined,
    component: IndustryViewScreen,
  },
  {
    path: '/industry',
    name: 'Industry',
    component: IndustryScreen,
  },
  {
    path: '/aboutus',
    name: 'About Us',
    component: AboutUsScreen,
  },
  {
    path: '/',
    name: 'Home',
    component: HomeScreen,
  },
];

export default navs;
