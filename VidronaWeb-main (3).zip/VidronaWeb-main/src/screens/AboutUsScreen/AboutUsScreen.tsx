import React from 'react';
import {motion} from 'framer-motion';

// importing styles
import './AboutUsScreen.css';

// importing components
import PageHeader from '../../components/PageHeader/PageHeader';
import
QuoteCarousel from '../../components/Carousel/QuoteCarousel/QuoteCarousel';
import ProfileCard from '../../components/ProfileCard/ProfileCard';

// raw data
const awards = [
  {
    body: 'Best Smart Grid Project in India 2021',
    image: require('./assets/awards/1.png').default,
  },
  {
    body: 'We innovate to improve the way the world works and lives',
    image: require('./assets/awards/2.png').default,
  },
  {
    body: 'Best Smart Grid Project in India 2021',
    image: require('./assets/awards/3.png').default,
  },
];

const AboutUsScreen = () => {
  return (
    <motion.div className="mainContainer">
      <PageHeader
        title="About Us"
        links={[
          {
            name: 'About Us',
            url: '/aboutus',
          },
        ]}
        image={require('./assets/aboutUs.png').default}
      />
      <motion.div className="BaseContentWrapper companyVisionWrapper">
        <motion.h2 className="companyVisionHeading">Company Vision</motion.h2>
        <motion.p className="companyVisionPara">
          Lorem ipsum is a pseudo-Latin text
          used in web design typography layout
          and printing in place of English to
          emphasise design elements over
          content. Its also called placeholder
          text. Its a convenient tool for mock-ups.

          Contrary to popular belief, Lorem
          Ipsum is not simply random text.
          It has roots in a piece of classical
          Latin literature from 45 BC, making
          it over 2000 years old. Richard
          McClintock, a Latin professor at
          Hampden-Sydney College in Virginia,
          looked up one of the more obscure
          Latin words, consectetur, from a
          Lorem Ipsum passage, and going
          through the cites of the word in
          classical literature, discovered
          the undoubtable source. Lorem Ipsum
          comes from sections 1.10.32 and 1.10.33
          of de Finibus Bonorum et Malorum
          (The Extremes of Good and Evil) by
          Cicero, written in 45 BC. This book
          is a treatise on the theory of ethics,
          very popular during the Renaissance.
        </motion.p>
      </motion.div>
      <motion.div className="ourApproachWrapper">
        <motion.img
          src={require('./assets/1.png').default}
          alt="Our Approach"
          className="ourApproachMainImage"
        />
        <motion.div className="ourApproachContent BaseContentWrapper">
          <motion.h2>Our Approach</motion.h2>
          <motion.p>
            Contrary to popular belief, Lorem Ipsum
            is not simply random text. It has roots
            in a piece of classical Latin literature
            from 45 BC, making it over 2000 years old.
          </motion.p>
          <motion.p>
            Richard McClintock, a Latin professor at
            Hampden-Sydney College in Virginia,
            looked up one of the more obscure Latin
            words, consectetur, from a Lorem Ipsum
            passage, and going through the cites of
            the word in classical literature,
            discovered the undoubtable source.
          </motion.p>
        </motion.div>
      </motion.div>
      <motion.div className="ourHistoryWrapper BaseContentWrapper">
        <motion.h2 className="ourHistoryHeading">
          Our History
        </motion.h2>
        <motion.div className="ourHistoryContent">
          <motion.p>
            Lorem ipsum is a pseudo-Latin text
            used in web design typography layout
            and printing in place of English to
            emphasise design elements over
            content. Its also called
            placeholder text. Its a convenient
            tool for mock-ups.
          </motion.p>
          <motion.p>
            Contrary to popular belief, Lorem
            Ipsum is not simply random text.
            It has roots in a piece of classical
            Latin literature from 45 BC, making
            it over 2000 years old. Richard
            McClintock, a Latin professor at
            Hampden-Sydney College in Virginia,
            looked up one of the more obscure
            Latin words, consectetur, from a
            Lorem Ipsum passage, and going
            through the cites of the word in
            classical literature, discovered
            the undoubtable source. Lorem Ipsum
            comes from sections 1.10.32 and 1.10.33
            of de Finibus Bonorum et Malorum
            (The Extremes of Good and Evil) by
            Cicero, written in 45 BC. This book
            is a treatise on the theory of ethics,
            very popular during the Renaissance.
          </motion.p>
          <motion.div className="ourHistoryCardGrid">
            <motion.img
              src={require('./assets/2.png').default}
              alt="our history"
              className="ourHistoryCardGridItem"
            />
            <motion.img
              src={require('./assets/3.png').default}
              alt="our history"
              className="ourHistoryCardGridItem"
            />
          </motion.div>
        </motion.div>
      </motion.div>
      <QuoteCarousel
        title="Awards and Recognition"
        data={awards}
      />
      <motion.div className="ourLeaderShipWrapper BaseContentWrapper">
        <motion.h2 className="ourLeaderShipHeading">
          Our Leadership
        </motion.h2>
        <motion.div className="ourLeaderShipContent">
          <motion.p>
            Lorem ipsum is a pseudo-Latin text used in web
            design typography layout and printing in place
            of English to emphasise design elements over
            content. Its also called placeholder text.
            Its a convenient tool for mock-ups.
          </motion.p>
          <ProfileCard
            name="Dr. Ashutosh Natraj"
            position="founder and CEO of Vidrona"
            image={require('./assets/4.png').default}
          />
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

export default AboutUsScreen;
