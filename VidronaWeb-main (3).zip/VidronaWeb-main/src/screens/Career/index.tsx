import React from 'react';
import {motion} from 'framer-motion';

// importing styles
import './index.css';

// importing components
import PageHeader from '../../components/PageHeader/PageHeader';
import
SectionCarousel
  from '../../components/Carousel/SectionCarousel/SectionCarousel';

// raw data
const careers = [
  {
    name: 'Drone/UAV Pilots',
    image: require('./assets/8.png').default,
    link: 'careers/drone',
  },
  {
    name: 'Software Engineer',
    image: require('./assets/2.png').default,
    link: 'careers/software',
  },
  {
    name: 'PhD Machine Learning',
    image: require('./assets/3.png').default,
    link: 'careers/mlphd',
  },
  {
    name: 'Hardware Engineer Drone/UAV',
    image: require('./assets/4.png').default,
    link: 'careers/hardware',
  },
  {
    name: 'Backend Integrator',
    image: require('./assets/5.png').default,
    link: 'careers/backend',
  },
  {
    name: 'Cude Programmer',
    image: require('./assets/6.png').default,
    link: 'careers/cude',
  },
  {
    name: 'Student Internships',
    image: require('./assets/7.png').default,
    link: 'careers/student',
  },
];

const CareerScreen = () => {
  return (
    <motion.div>
      <PageHeader
        title="Careers"
        links={[
          {
            name: 'Careers',
            link: '/careers',
          },
        ]}
        image={require('./assets/careers.png').default}
      />
      <motion.div className="exploreOpportunity BaseContentWrapper">
        <motion.h2>
          Explore Opportunities
        </motion.h2>
        <motion.p>
          Are you a self starter, team worker, focused and
          think out of the box innovtive implementation
          either for job /internships? Move forward. Take
          the world with you. Please send your resumes to
          info@vidrona.com
        </motion.p>
        <SectionCarousel data={careers} />
      </motion.div>
      <motion.div className="exploreVidronaWrappper BaseContentWrapper">
        <motion.div
          className="exploreVidronaContentWrapper"
        >
          <motion.div className="exploreVidronaContentInner">
            <motion.h2>
              Explore Vidrona
            </motion.h2>
            <motion.p>
              Vidrona is driven by the passion and talent
              of our employees worldwide. If you have the
              skills and motivation to deliver innovative
              solutions for some of the biggest brands in
              the world, we want you on our global team
            </motion.p>
          </motion.div>
        </motion.div>
        <motion.div className="exploreVidronaBlackBar" />
      </motion.div>
    </motion.div>
  );
};

export default CareerScreen;
