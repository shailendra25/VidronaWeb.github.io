import React from 'react';
import {motion} from 'framer-motion';

// importing styles
import './ContactUsScreen.css';

// importing components
import PageHeader from '../../components/PageHeader/PageHeader';

const ContactUsScreen = () => {
  return (
    <motion.div>
      <PageHeader
        title="Contact Us"
        links={[
          {
            name: 'Contact Us',
            link: '/contactus',
          },
        ]}
        image={require('./assets/contactUs.png').default}
      />
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d636805.8395817517!2d-1.0728571382637542!3d51.43019187230564!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4876ba143adedbdb%3A0x1fe603684b065beb!2sVidrona%20Ltd!5e0!3m2!1sen!2sin!4v1621228050517!5m2!1sen!2sin"
        width="600"
        height="450"
        className="mapWrapper"
        loading="lazy">
      </iframe>
      <motion.div className="contactUsContainer BaseContentWrapper">
        <motion.div className="contactUsContainerSide">
          <motion.div className="contactUsContainerItem">
            <motion.img
              src={require('./assets/1.png').default}
            />
            <motion.h6>
              G10 Atlas Building European Space Agency: BIC Campus,
              Fermi Avenue, Harwell, Didcot OX11 0QX, United Kingdom
            </motion.h6>
          </motion.div>
          <motion.div className="contactUsContainerItem">
            <motion.img
              src={require('./assets/2.png').default}
            />
            <motion.h6>
              info@vidrona.com
            </motion.h6>
          </motion.div>
          <motion.div className="contactUsContainerItem">
            <motion.img
              src={require('./assets/3.png').default}
            />
            <motion.h6>
              +447469231693
            </motion.h6>
          </motion.div>
          <motion.div className="contactUsContainerItem">
            <motion.img
              src={require('./assets/4.png').default}
            />
            <motion.h6>
              WhatsApp us (Free International Message)
            </motion.h6>
          </motion.div>
        </motion.div>
        <motion.div className="contactUsContainerSide">
          <motion.div className="contactUsContainerInnerCard">
            <motion.h4>
              Connect With Us
            </motion.h4>
            <motion.p>
              Please contact us to know more about
              Vidrona and its products (vSense,vNautilus).
            </motion.p>
            <motion.div className="contactUsInputWrapper">
              <motion.input
                type="text"
                placeholder="First Name"
                className="contactUsInputField"
              />
              <motion.input
                type="text"
                placeholder="Last Name"
                className="contactUsInputField"
              />
            </motion.div>
            <motion.div className="contactUsInputWrapper">
              <motion.input
                type="text"
                placeholder="Email"
                className="contactUsInputField"
              />
              <motion.input
                type="text"
                placeholder="Phone No."
                className="contactUsInputField"
              />
            </motion.div>
            <motion.textarea
              placeholder="Message"
              className="contactUsInputTextArea"
            />
            <motion.button className="contactUsButton">
              Send Message
            </motion.button>
          </motion.div>
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

export default ContactUsScreen;
