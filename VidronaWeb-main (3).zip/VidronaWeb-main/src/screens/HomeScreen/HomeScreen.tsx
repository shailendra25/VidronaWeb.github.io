import React from 'react';
import {motion} from 'framer-motion';

// importing styles
import './HomeScreen.css';

// importing components
import
FullPageCarousel
  from '../../components/Carousel/FullPageCarousel/FullPageCarousel';
import FadeCard from '../../components/FadeCard/FadeCard';
import ListCarousel from '../../components/ListCarousel/ListCarousel';
import
QuoteCarousel from '../../components/Carousel/QuoteCarousel/QuoteCarousel';
import StayAwareBar from '../../components/StayAwareBar/StayAwareBar';

// raw data for page
const industrySolutions = [
  {
    name: 'Transmission',
    image: require('../../assets/icons/transmission.svg').default,
  },
  {
    name: 'Solar',
    image: require('../../assets/icons/solar.svg').default,
  },
  {
    name: 'Wind',
    image: require('../../assets/icons/windmill.svg').default,
  },
  {
    name: 'Microgrid',
    image: require('../../assets/icons/microgrid.svg').default,
  },
  {
    name: 'Telecom',
    image: require('../../assets/icons/telecom.svg').default,
  },
  {
    name: 'Rail',
    image: require('../../assets/icons/rail.svg').default,
  },
];
const whatWeDo = [
  {
    title: 'Data Acquisition',
    // eslint-disable-next-line max-len
    body: 'Quality data collection services offered by drones, helicoptersand satellite catteringas per the customer and project requirement',
    image: require('../../assets/images/drone.png').default,
    link: '',
  },
  {
    title: 'Fault Identification',
    // eslint-disable-next-line max-len
    body: 'Machine Learning based 75+ typehuman error free precision fault identifications with actionable items',
    image: require('../../assets/images/tower.png').default,
    link: '',
  },
  {
    title: 'Predictive Analysis',
    // eslint-disable-next-line max-len
    body: 'Our AI based predictive analytics to identify faults with high confidence with optimised scheduled maintainance',
    image: require('../../assets/images/laptop.png').default,
    link: '',
  },
  {
    title: 'Process Optimisation',
    // eslint-disable-next-line max-len
    body: 'Enhancing your engineering business process by optimising Asset maintainance inventory managemant and procurement',
    image: require('../../assets/images/process.png').default,
    link: '',
  },
  {
    title: 'Robotics Research',
    // eslint-disable-next-line max-len
    body: 'We are commited towards developing innovative cutting edge technology to cater the ever changing complex challenges and needs of our customers and industry',
    image: require('../../assets/images/robot.png').default,
    link: '',
  },
  {
    title: 'Virtual Reality Integration',
    // eslint-disable-next-line max-len
    body: 'Our state of the art Virtual reality goggle help Engineering team to asses and plan maintainance task easier',
    image: require('../../assets/images/vr.png').default,
    link: '',
  },
];
const ourSolution = [
  {
    heading: 'vSense',
    // eslint-disable-next-line max-len
    body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ultrices consequat massa, ac porta ante. Ut pharetra posuere libero vel porttitor. Morbi eget molestie massa. Phasellus eu sollicitudin dui, nec imperdiet leo. Suspendisse aliquet volutpat scelerisque. Integer mollis finibus leo, et dignissim nunc faucibus in.',
    image: require('../../assets/images/services/vSense.png').default,
  },
  {
    heading: 'vAeolus',
    // eslint-disable-next-line max-len
    body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ultrices consequat massa, ac porta ante. Ut pharetra posuere libero vel porttitor. Morbi eget molestie massa. Phasellus eu sollicitudin dui, nec imperdiet leo. Suspendisse aliquet volutpat scelerisque. Integer mollis finibus leo, et dignissim nunc faucibus in.',
    image: require('../../assets/images/services/vAeolus.png').default,
  },
  {
    heading: 'vSolis',
    // eslint-disable-next-line max-len
    body: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ultrices consequat massa, ac porta ante. Ut pharetra posuere libero vel porttitor. Morbi eget molestie massa. Phasellus eu sollicitudin dui, nec imperdiet leo. Suspendisse aliquet volutpat scelerisque. Integer mollis finibus leo, et dignissim nunc faucibus in.',
    image: require('../../assets/images/services/vSolis.png').default,
  },
];

const HomeScreen = () => {
  return (
    <motion.div className="mainContainer">
      {/* Full page carosol */}
      <FullPageCarousel />
      <motion.div className="factAndFiguresWrapper BaseContentWrapper">
        <motion.h3>
          Facts and Figures
        </motion.h3>
        <motion.div className="factAndFigureStatsWrapper">
          <motion.div className="factAndFigureStats">
            <motion.h3>7+</motion.h3>
            <motion.h4>Products Created</motion.h4>
          </motion.div>
          <motion.div className="factAndFigureStats">
            <motion.h3>5+</motion.h3>
            <motion.h4>Products Created</motion.h4>
          </motion.div>
          <motion.div className="factAndFigureStats">
            <motion.h3>105+</motion.h3>
            <motion.h4>Products Created</motion.h4>
          </motion.div>
          <motion.div className="factAndFigureStats">
            <motion.h3>31+</motion.h3>
            <motion.h4>Products Created</motion.h4>
          </motion.div>
        </motion.div>
      </motion.div>
      <motion.div className="industrySolutionsWrapper BaseContentWrapper">
        <motion.div className="industrySolutionsSideContainer">
          <motion.h2 className="industrySolutionsHeading">
            Our Industry Solution
          </motion.h2>
          <motion.p className="industrySolutionsPara">
            We provide comprehensive AI based solutions
            for your Energy Asset Maintenance and
            Management requirements. Our specialised
            teams capture your Asset Data using drones,
            helicopters, and other suitable methods
            without any need of transmission outage.
          </motion.p>
        </motion.div>
        <motion.div
          className="industrySolutionsSideContainer industrySolutionsSideGrid"
        >
          {
            industrySolutions.map((sol) => {
              return (
                <motion.div
                  key={sol.name}
                  className="industrySolutionsSideGridItem"
                >
                  <motion.img
                    src={sol.image}
                    alt={sol.name}
                  />
                  <motion.h5>
                    {sol.name}
                  </motion.h5>
                </motion.div>
              );
            })
          }
        </motion.div>
      </motion.div>
      <motion.div className="whatWeDoWrapper BaseContentWrapper">
        <motion.h2 className="whatWeDoHeading">
          What We Do
        </motion.h2>
        <motion.h5 className="whatWeDoSubHeading">
          We bring you powerful advantages to
          navigate your digital transformation
        </motion.h5>
        <motion.div className="whatWeDoGrid">
          {
            whatWeDo.map((data) => {
              return (
                <motion.div key={data.title} className="whatWeDoGridItem">
                  <FadeCard
                    title={data.title}
                    body={data.body}
                    image={data.image}
                    link={data.link}
                  />
                </motion.div>
              );
            })
          }
        </motion.div>
      </motion.div>
      <ListCarousel
        title="Our Analytics Product Suit"
        data={ourSolution}
      />
      <motion.div className="ourServicesWrapper BaseContentWrapper">
        <motion.div className="ourServicesHeadingContainer">
          <motion.h2>
            Our Services
          </motion.h2>
        </motion.div>
        <motion.div className="ourServicesInfoContainer">
          <motion.div className="ourServicesImageContainer">
            <motion.img
              src={require('../../assets/icons/services/1.png').default}
              alt="service"
            />
            <motion.img
              src={require('../../assets/icons/services/2.png').default}
              alt="service"
            />
            <motion.img
              src={require('../../assets/icons/services/3.png').default}
              alt="service"
            />
            <motion.img
              src={require('../../assets/icons/services/4.png').default}
              alt="service"
            />
          </motion.div>
          <motion.h2 className="ourSerivesInfoHeading">
            A High Level Quality Control in
            Compliance with National and In
            International regulations and starnards.
          </motion.h2>
          <motion.p className="ourSerivesIntoPara">
            We provide comprenhensive AI based
            solutions for your Energy Asset
            Maintainance and Management
            requirements. Our specialised team
            capture your Asset data using drone,
            helicopter, and other suitable
            methods without any need for
            transmission outage. Data is pushed
            to Vidrona’s cloud platform and
            analysed using our propretiary
            computer vision and maching learning
            algorithm to detect technical fault
            exhaustively.
          </motion.p>
        </motion.div>
      </motion.div>
      <QuoteCarousel
        title="Customers and Collabortors"
        // data={[]}
      />
      <StayAwareBar />
    </motion.div>
  );
};

export default HomeScreen;
