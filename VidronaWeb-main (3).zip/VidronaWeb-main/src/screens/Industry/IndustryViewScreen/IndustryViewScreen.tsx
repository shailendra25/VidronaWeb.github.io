import React from 'react';
import {motion} from 'framer-motion';
import {useParams} from 'react-router-dom';

// import styles
import './IndustryViewScreen.css';

// importing components
import PageHeader from '../../../components/PageHeader/PageHeader';
import FadeCard from '../../../components/FadeCard/FadeCard';

// import raw data
import {getRawData} from './raw';

type IndustryViewParams = {
  industryId: string;
}

const IndustryViewScreen = () => {
  const {industryId}: IndustryViewParams = useParams();
  const data = getRawData(industryId);
  return (
    <motion.div>
      <PageHeader
        title={`${data.pageTitle} Industry`}
        links={[
          {
            name: 'Industry',
            url: '/industry',
          },
          {
            name: industryId,
            url: `/industry/${industryId}`,
          },
        ]}
        image={require('../assets/industry.png').default}
      />
      <motion.div className="industryViewDescriptionWrapper BaseContentWrapper">
        <motion.div className="industryViewVideoSection">
          <motion.div
            className="industryViewVideo"
          />
          <motion.div className="industryViewVideoPoints">
            <ul>
              {
                data.video.points.map((point: string, index: number) => {
                  return (
                    <motion.li key={index}>
                      {point}
                    </motion.li>
                  );
                })
              }
            </ul>
          </motion.div>
        </motion.div>
        <motion.h2>
          {data.pageTitle}
        </motion.h2>
        {
          data.pageDesc.map((para: string, index: number) => {
            return (
              <motion.p key={index}>
                {para}
              </motion.p>
            );
          })
        }
      </motion.div>
      <motion.div className="industryViewAnalyticsProduct BaseContentWrapper">
        <motion.h2>
          Our Analytics Product for Powerline Industry
        </motion.h2>
        <motion.div className="industryViewAnalyticsInner">
          {
            data.analysisProducts.map((ap: any) => {
              return (
                <motion.div
                  key={ap.title}
                  className="industryViewAnalyticsCard"
                >
                  <motion.img
                    src={ap.image}
                  />
                  <motion.h6>
                    {ap.title}
                  </motion.h6>
                  <motion.p>
                    Powered by Vidrona
                  </motion.p>
                </motion.div>
              );
            })
          }
        </motion.div>
      </motion.div>
      <motion.div className="industryViewAssetAnalysis BaseContentWrapper">
        <motion.h2>
          Asset Analytics
        </motion.h2>
        <motion.div className="industryViewAssetAnalysisInner">
          <motion.div className="industryViewAssetAnalysisContent">
            <motion.img
              src={data.assetAnalysisImage}
            />
          </motion.div>
          <motion.div className="industryViewAssetAnalysisContent">
            {
              data.assetAnalysisParas.map((para: string, index: number) => {
                return (
                  <motion.p key={index}>
                    {para}
                  </motion.p>
                );
              })
            }
          </motion.div>
        </motion.div>
      </motion.div>
      <motion.div
        className="industryViewAssetAnalysis BaseContentWrapper"
        style={{
          backgroundColor: 'white',
        }}
      >
        <motion.h2>
          Environmental Analysis
        </motion.h2>
        <motion.div className="industryViewAssetAnalysisInner">
          <motion.div className="industryViewAssetAnalysisContent">
            <motion.img
              src={data.envAnalysisImage}
            />
          </motion.div>
          <motion.div className="industryViewAssetAnalysisContent">
            {
              data.envAnalysisParas.map((para: string, index: number) => {
                return (
                  <motion.p key={index}>
                    {para}
                  </motion.p>
                );
              })
            }
          </motion.div>
        </motion.div>
      </motion.div>
      <motion.div className="industryViewSampleWork BaseContentWrapper">
        <motion.h2>
          Sample of our work
        </motion.h2>
        <motion.div className="industryViewSampleWorkInner">
          {
            data.sampleWorks.map((sw: any) => {
              return (
                <motion.div
                  key={sw.title}
                  style={{
                    marginRight: 20,
                    marginBottom: 20,
                  }}
                >
                  <FadeCard
                    title={sw.title}
                    body={sw.body}
                    image={sw.image}
                    link={sw.image}
                  />
                </motion.div>
              );
            })
          }
        </motion.div>
      </motion.div>
      <motion.div className="startYourVidExp BaseContentWrapper">
        <motion.h2>
          Start your Vidrona Experience
        </motion.h2>
        <motion.a href="/contactus">
          Contact Us
        </motion.a>
      </motion.div>
    </motion.div>
  );
};

export default IndustryViewScreen;
