import React from 'react';
import {motion} from 'framer-motion';

// importing styles
import './index.css';

// importing components
import PageHeader from '../../components/PageHeader/PageHeader';
import IndustryCard from '../../components/Cards/IndustryCard/IndustryCard';

// raw data
const industry = [
  {
    title: 'Power Lines',
    // eslint-disable-next-line max-len
    body: 'We have services for systematic predictive inspection for the New power lines, semi finished lines',
    link: '/industry/powerline',
    image: require('./assets/1.png').default,
  },
  {
    title: 'Solar',
    // eslint-disable-next-line max-len
    body: 'We provide our customers with bespoke daily, weekly, monthly, quartely and annual reports',
    link: '/industry/solar',
    image: require('./assets/3.png').default,
  },
  {
    title: 'Wind',
    // eslint-disable-next-line max-len
    body: 'Wind turbine inspection is reactibe, expensive, health and saftey hazard prone to errors',
    link: '/industry/wind',
    image: require('./assets/4.png').default,
  },
  {
    title: 'Microgrid',
    // eslint-disable-next-line max-len
    body: 'Our microgrid service provide predictive and perspective analytics to reduce the electricity cost',
    link: '/industry/microgrid',
    image: require('./assets/2.png').default,
  },
];

const IndustryScreen = () => {
  return (
    <motion.div>
      <PageHeader
        title="Industry"
        links={[{name: 'Industry', url: '/industry'}]}
        image={require('./assets/industry.png').default}
      />
      <motion.div className="industryFocusedAreaWrapper BaseContentWrapper">
        <motion.h4>
          Our Innovations
        </motion.h4>
        <motion.h2>
          Industry Focused Areas
        </motion.h2>
        <motion.p>
          We provide comprehensive AI based solutions
          for your Energy Asset Maintenance and
          Management requirements. Our specialised
          teams capture your Asset Data using drones,
          helicopters, and other suitable methods
          without any need of transmission outage.
        </motion.p>
        <motion.div className="industryFocusedAreaCardsWrapper">
          {
            industry.map((ind) => {
              return (
                <motion.div style={{padding: 10}} key={ind.title}>
                  <IndustryCard
                    title={ind.title}
                    body={ind.body}
                    link={ind.link}
                    image={ind.image}
                  />
                </motion.div>
              );
            })
          }
        </motion.div>
      </motion.div>
      <motion.div className="weAreExpertsWrapper BaseContentWrapper">
        <motion.h2>
          Need help with easier industrial solutions? We are experts!
        </motion.h2>
      </motion.div>
    </motion.div>
  );
};

export default IndustryScreen;
