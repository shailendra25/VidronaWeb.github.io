import React from 'react';
import {motion} from 'framer-motion';

// importing styles
import './ServiceScreen.css';

// importing components
import PageHeader from '../../components/PageHeader/PageHeader';

// raw data
const services = [
  {
    name: 'Professional Team',
    // eslint-disable-next-line max-len
    body: 'Lorem ipsum is a pseudo-Latin text used in web design typography layout and printing in place of English to emphasise design elements over continue.',
    image: require('./images/7.png').default,
  },
  {
    name: 'Delivery on Time',
    // eslint-disable-next-line max-len
    body: 'Lorem ipsum is a pseudo-Latin text used in web design typography layout and printing in place of English to emphasise design elements over continue.',
    image: require('./images/8.png').default,
  },
  {
    name: 'Quality Products',
    // eslint-disable-next-line max-len
    body: 'Lorem ipsum is a pseudo-Latin text used in web design typography layout and printing in place of English to emphasise design elements over continue.',
    image: require('./images/9.png').default,
  },
  {
    name: '#1 Manufacturing Unit',
    // eslint-disable-next-line max-len
    body: 'Lorem ipsum is a pseudo-Latin text used in web design typography layout and printing in place of English to emphasise design elements over continue.',
    image: require('./images/10.png').default,
  },
];

const ServiceScreen = () => {
  return (
    <motion.div>
      <PageHeader
        title="Services"
        links={[{name: 'Services', link: '/services'}]}
        image={require('./images/services.png').default}
      />
      <motion.div className="industryReadyWrapper BaseContentWrapper">
        <motion.div className="industryReadyContentContainer">
          <motion.h2>
            Optimised and Industry Ready Solutions
          </motion.h2>
          <motion.p>
            We provide comprehensive AI based solutions
            for your Energy Asset Maintenance and
            Management requirements. Our specialised
            teams capture your Asset Data using drones,
            helicopters, and other suitable methods
            without any need of transmission outage.
          </motion.p>
        </motion.div>
        <motion.div>
          <motion.img
            src={require('./images/1.png').default}
            alt="Wind Mill"
            className="industryReadyImage"
          />
          <motion.img
            src={require('./images/2.png').default}
            alt="Wind Mill"
            className="industryReadyImage"
          />
        </motion.div>
      </motion.div>
      <motion.div className="factsWrapper BaseContentWrapper">
        <motion.h2 className="factsHeading">
          Facts
        </motion.h2>
        <motion.p className="factsPara">
          A High Level Quality Control in Compliance
          with National and in International regulations
          and starnards.
        </motion.p>
        <motion.div className="factsImageWrapper">
          <motion.img
            src={require('./images/3.png').default}
            alt="1"
          />
          <motion.img
            src={require('./images/4.png').default}
            alt="1"
          />
          <motion.img
            src={require('./images/5.png').default}
            alt="1"
          />
        </motion.div>
      </motion.div>
      <motion.div className="serviceWorldwideWrapper BaseContentWrapper">
        <motion.div className="serviceWorldwideSide">
          <motion.img
            src={require('./images/6.png').default}
            alt="Established in 2015"
          />
        </motion.div>
        <motion.div className="serviceWorldwideSide">
          <motion.h2>
            We provide the best
          </motion.h2>
          <motion.h2>
            Industrial Service Worldwide
          </motion.h2>
          <motion.p>
            Lorem ipsum is a pseudo-Latin text used in
            web design typography layout and printing
            in place of English to emphasise design
            elements over content. Its also called
            placeholder text. Its a convenient tool
            for mock-ups.
          </motion.p>
          <motion.caption>
            Contrary to popular belief, Lorem Ipsum is
            not simply random text. It has roots in a
            piece of classical Latin literature from
            45 BC, making it over 2000 years old.
            Richard McClintock, a Latin professor at
            Hampden-Sydney College in Virginia, looked
            up one of the more obscure Latin words,
            consectetur, from a Lorem Ipsum passage,
            and going through the cites of the word
            in classical literature, discovered the
            undoubtable source.
          </motion.caption>
          <motion.h3>
            We have 5+ years of Experience for give you better results
          </motion.h3>
        </motion.div>
      </motion.div>
      <motion.div className="descriptiveCardsWrapper BaseContentWrapper">
        <motion.div className="descriptiveCardsGrid">
          {
            services.map((serv) => {
              return (
                <motion.div key={serv.name} className="descriptiveCardsItem">
                  <motion.img
                    src={serv.image}
                    alt="7"
                    style={{
                      alignSelf: 'flex-start',
                    }}
                  />
                  <motion.div className="descriptiveCardContent">
                    <motion.h4>
                      {serv.name}
                    </motion.h4>
                    <motion.p>
                      {serv.body}
                    </motion.p>
                  </motion.div>
                </motion.div>
              );
            })
          }
        </motion.div>
      </motion.div>
      <motion.div className="ourTeamWrapper BaseContentWrapper">
        <motion.div className="ourTeamSideTitle">
          <motion.h2>
            Our Team
          </motion.h2>
        </motion.div>
        <motion.div className="ourTeamSideContainer">
          <motion.p>
            Lorem ipsum is a pseudo-Latin text used in
            web design typography layout and printing
            in place of English to emphasise design
            elements over content. Its also called
            placeholder text. Its a convenient tool
            for mock-ups.
          </motion.p>
          <motion.div className="ourTeamSideCardWrapper">
            <motion.div
              style={{
                width: 200,
                height: 200,
                backgroundColor: 'white',
                margin: 10,
              }}
            />
            <motion.div
              style={{
                width: 200,
                height: 200,
                backgroundColor: 'white',
                margin: 10,
              }}
            />
            <motion.div
              style={{
                width: 200,
                height: 200,
                backgroundColor: 'white',
                margin: 10,
              }}
            />
          </motion.div>
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

export default ServiceScreen;
