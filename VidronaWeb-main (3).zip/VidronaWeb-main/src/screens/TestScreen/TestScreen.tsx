import React from 'react';

// importing components
import Button from '../../components/Button/Button';
import FlipCard from '../../components/FlipCard/FlipCard';
import FadeCard from '../../components/FadeCard/FadeCard';
import
FullPageCarousel from '../../components/ListCarousel/ListCarousel';

// importing styles
import './TestScreen.css';

const TestScreen = () => {
  return (
    <div className="mainTestContainer">
      <h1>Test Screen</h1>
      <p>
        All components will be individually listed here,
        with possible all different versions.
      </p>
      <div className="testSection">
        <h2>Button</h2>
        <div className="testSectionInner">
          <Button />
          <Button text="Custom Text" />
          <Button
            text="OnPress"
            onPress={() => {
              alert('Button with onPress clicked');
            }}
          />
          <Button
            text="Disabled"
            isDisabled={true}
          />
          <Button type="dark" />
        </div>
      </div>
      <div className="testSection">
        <h2>Flip Cards</h2>
        <div className="testSectionInner">
          <FlipCard />
        </div>
      </div>
      <div className="testSection">
        <h2>Fade Cards</h2>
        <div className="testSectionInner">
          <FadeCard />
        </div>
      </div>
      <div className="testSection">
        <h2>Full Page Carousel</h2>
        <div className="testSectionInner">
          <FullPageCarousel flipped={true} />
        </div>
      </div>
    </div>
  );
};

export default TestScreen;
